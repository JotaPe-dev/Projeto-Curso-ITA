package oo.cursoita;

import java.util.HashMap;
import java.util.Map;

public class CarrinhoDeCompras {
    private Map<Produto, Integer> carrinho = new HashMap<>();
    private static int qtdNoCarrinho;
    private static double total= 0;

    public void adicionaProduto(Produto p, int qtd){
        if (carrinho.containsKey(p))
        {
            carrinho.put(p, qtd+=qtd);
        }
        else carrinho.put(p, qtd);
        qtdNoCarrinho += qtd;
    }

    public void removeProduto(Produto p, int qtd){
        if (carrinho.containsKey(p))
        {
            carrinho.remove(p);
            qtdNoCarrinho -= qtd;
        }
    }


    public double getPrecoTotalCarrinho(){
        for(Produto p : carrinho.keySet() ){
            total = p.getPreco() * qtdNoCarrinho;
        }
        return total;
    }
    public HashMap<Produto, Integer> getCarrinho(){
        return (HashMap<Produto, Integer>) carrinho;
    }
    public void setCarrinho(HashMap<Produto, Integer> carrinho){
        this.carrinho = carrinho;
    }
    public static int getQuantidadeNoCarrinho(){
        return qtdNoCarrinho;
    }
    public static void setQuantidadeNoCarrinho(int quantidadeNoCarrinho){
        CarrinhoDeCompras.qtdNoCarrinho = quantidadeNoCarrinho;
    }


}