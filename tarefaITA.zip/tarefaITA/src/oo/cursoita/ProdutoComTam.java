package oo.cursoita;

public class ProdutoComTam extends Produto {

    private int tam;

    public ProdutoComTam(int codigo,String nome, double preco, int tam){
        super(codigo, nome, preco);
        this.tam = tam;

    }

    public ProdutoComTam(int codigo, String nome, double preco){
        super(codigo, nome, preco);
    }

    @Override
    public int hashCode(){
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result  + tam;
        return result;
    }

    @Override
    public boolean equals(Object object){
        if (!(object instanceof ProdutoComTam))
            return false;
        ProdutoComTam outroProduto = (ProdutoComTam) object;


        if(this.hashCode() == outroProduto.hashCode())
            return true;
        else return false;
    }


}