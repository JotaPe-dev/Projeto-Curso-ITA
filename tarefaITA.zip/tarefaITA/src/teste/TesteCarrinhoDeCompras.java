package teste;

import oo.cursoita.CarrinhoDeCompras;
import oo.cursoita.Produto;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public  class  TesteCarrinhoDeCompras{

    @Test
    public  void  testeQuantidadeNoCarrinho (){
        Produto p =  new  Produto ( 12 , " Calça Jeans " , 15 );
        CarrinhoDeCompras c1 =  new  CarrinhoDeCompras ();
        c1 . adicionaProduto(p, 3 );
        assertEquals( CarrinhoDeCompras . getQuantidadeNoCarrinho(), 3 );

    }
}