package teste;

import oo.cursoita.Produto;
import oo.cursoita.ProdutoComTam;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TesteProdutoComTamanho {

    @Test
    public void testeEquals() {

        Produto pt = new ProdutoComTam(1, "Bone", 20, 5);
        Produto pt1 = new ProdutoComTam(1, "Calça", 22, 15);
        assertEquals(pt.equals(pt1), pt1.equals(pt));
    }

    @Test
    public void testeHashCode()
    {
        Produto pt = new ProdutoComTam(1, "Capacete", 25, 5);
        Produto pt1 = new ProdutoComTam(1, "Bone", 20, 5);
        assertEquals(pt.hashCode(), pt1.hashCode());

    }


}