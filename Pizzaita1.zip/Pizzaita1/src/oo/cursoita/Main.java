package oo.cursoita;

public class Main {

    public static void main(String[] args) {

        Pizza p1 = new Pizza();
        Pizza p2 = new Pizza();
        Pizza p3 = new Pizza();
        Pizza p4 = new Pizza();

        p1.adicionaIngrediente("Calabresa");
        p1.adicionaIngrediente("Mucarela");
        p1.adicionaIngrediente("Cebola");
        p1.adicionaIngrediente("Molho de Tomate");

        p2.adicionaIngrediente("Frango");
        p2.adicionaIngrediente("Catupiry");
        p2.adicionaIngrediente("Mucarela");
        p2.adicionaIngrediente("Milho");
        p2.adicionaIngrediente("Azeitona");
        p2.adicionaIngrediente("Molho de Tomate");
        p2.adicionaIngrediente("Borda Recheada");
        p2.adicionaIngrediente("Respingo de Solda");

        p3.adicionaIngrediente("Tomate seco");
        p3.adicionaIngrediente("Rucula");
        p3.adicionaIngrediente("Musarela de Bufula");
        p3.adicionaIngrediente("Molho de Tomate");

        p4.adicionaIngrediente("Molho De Tomate");
        p4.adicionaIngrediente("Mussarela");
        p4.adicionaIngrediente("Calabresa Ralada");
        p4.adicionaIngrediente("Pimentão Verde");
        p4.adicionaIngrediente("Pimenta Calabresa");
        p4.adicionaIngrediente("Cebola");

        CarrinhoDeCompras c = new CarrinhoDeCompras();

        c.addPizza(p1);
        c.addPizza(p2);
        c.addPizza(p3);
        c.addPizza(p4);


        System.out.println("Quantidade de pizzas que tem no carrinho: " +c.totalPizzas());
        System.out.println("Valor total da compra: " + c.getPrecoTotal());


        System.out.println("ingredientes que foram utilizados: \n" + Pizza.getListadeIngredientes());



    }

}

