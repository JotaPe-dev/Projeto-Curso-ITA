package oo.cursoita;

import java.util.ArrayList;

public class CarrinhoDeCompras{

    private ArrayList <Main> pizzas = new ArrayList <Main>();
    private double precoTotal =0;

    public void addPizza(Main p){
        if (p.getIngrediente().isEmpty()){}
        else
            pizzas.add(p);
    }

    public int totalPizzas(){
        return pizzas.size();
    }

    public double getPrecoTotal(){
        for(int i=0; i< pizzas.size(); i++){
            precoTotal += pizzas.get(i).getPreco();
        }
        return precoTotal;
    }

}