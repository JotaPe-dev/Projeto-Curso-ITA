package oo.cursoita;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class Main {

    public static void main(String[] args){

    }

    public static int totaldeIngredientes=0;
    private double preco;
    private ArrayList <String>  ingredientes = new ArrayList<String>();
    public static Map <String, Integer> mapadeIngredientes = new HashMap <String, Integer> ();


    public ArrayList<String> getIngrediente(){
        return ingredientes;
    }

    public static Map<String, Integer>  getListadeIngredientes(){
        return   mapadeIngredientes;
    }

    public void adicionaIngrediente (String ingrediente){
        this.ingredientes.add(ingrediente);
        contabilizaIngrediente(ingrediente);
    }

    public double getPreco (){
        if (ingredientes.size() <= 2){
            preco = 15;
        }
        if (ingredientes.size() >= 3 && ingredientes.size() <=5){
            preco = 20;
        }
        if (ingredientes.size() > 5){
            preco = 23;
        }
        return preco;
    }

    public static void contabilizaIngrediente(String ingrediente){
        if (mapadeIngredientes.containsKey(ingrediente)){
            int value = mapadeIngredientes.get(ingrediente);
            mapadeIngredientes.put(ingrediente, value+1);
        }
        else{
            mapadeIngredientes.put(ingrediente, 1);
        }
        totaldeIngredientes++;

    }


}