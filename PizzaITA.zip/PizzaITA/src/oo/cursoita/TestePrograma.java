package oo.cursoita;

public class TestePrograma {

    public static void main(String[] args) {

        Main p1 = new Main();
        Main p2 = new Main();
        Main p3 = new Main();

        p1.adicionaIngrediente("Calabresa");
        p1.adicionaIngrediente("Mucarela");
        p1.adicionaIngrediente("Cebola");
        p1.adicionaIngrediente("Molho de Tomate");

        p2.adicionaIngrediente("Frango");
        p2.adicionaIngrediente("Catupiry");
        p2.adicionaIngrediente("Mucarela");
        p2.adicionaIngrediente("Milho");
        p2.adicionaIngrediente("Azeitona");
        p2.adicionaIngrediente("Molho de Tomate");
        p2.adicionaIngrediente("Borda Recheada");
        p2.adicionaIngrediente("Respingo de Solda");

        p3.adicionaIngrediente("Tomate seco");
        p3.adicionaIngrediente("Rucula");
        p3.adicionaIngrediente("Musarela de Bufula");
        p3.adicionaIngrediente("Molho de Tomate");

        CarrinhoDeCompras c = new CarrinhoDeCompras();

        c.addPizza(p1);
        c.addPizza(p2);
        c.addPizza(p3);

        // Ira imprimeir o total do CarrinhoDeCompra
        System.out.println("Quantidade de pizzas que tem no carrinho: " +c.totalPizzas());
        System.out.println("Valor total da compra: " + c.getPrecoTotal());

        // Ira imprime a quantidade utilizada de cada ingrediente
        System.out.println("ingredientes que foram utilizados: \n" + Main.getListadeIngredientes());



    }

}