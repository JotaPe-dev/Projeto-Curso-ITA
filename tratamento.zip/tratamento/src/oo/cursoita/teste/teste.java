package oo.cursoita.teste;

import oo.cursoita.*;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

class TesteMain {

    @Test
    public void testeInformal()
    {
        FormatadorNome fn = new Informal();
        Main a = new Main ("Gabriel", "Oliveira", (FormatodorNome) fn);
        assertEquals(a.getTratamento(), "Gabriel");
    }

    @Test
    public void testeRespeitosoMasculino ()
    {
        FormatadorNome fn = new Respeitoso(true, false);
        Main a = new Main ("Gabriel", "Oliveira", (FormatodorNome) fn);
        assertEquals(a.getTratamento(), "Sr. Gabriel Oliveira");
    }

    @Test
    public void testeRespeitosoFeminino ()
    {
        FormatadorNome fn = new Respeitoso(false, true);
        Main a = new Main ("Marlenilde", "Ferreira", (FormatodorNome) fn);
        assertEquals(a.getTratamento(), "Sra. Marlenilde Ferreira");
    }

    @Test
    public void testeComTitulo ()
    {
        FormatadorNome fn = new ComTitulo("Excelentissimo");
        Main a = new Main ("Gabriel", "Oliveira", (FormatodorNome) fn);
        assertEquals(a.getTratamento(), "Excelentissimo Gabriel Oliveira");
    }

}