package oo.cursoita;

public class Informal implements FormatadorNome{


    public String formatarNome(String nome, String sobrenome){

        return nome;
    }

}