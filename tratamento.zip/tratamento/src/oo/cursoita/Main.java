package oo.cursoita;

public class Main {

    private String nome;
    private String sobrenome;
    private FormatodorNome fn;


    public static void main(String[] args){

        
    }
    public Main(String nome, String sobrenome, FormatodorNome fn){
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.fn = fn;
    }


    public String getTratamento(){
        return fn.formatarNome(nome, sobrenome);
    }


}