package oo.cursoita;


public interface FormatodorNome {


    String formatarNome(String nome, String sobrenome);


}