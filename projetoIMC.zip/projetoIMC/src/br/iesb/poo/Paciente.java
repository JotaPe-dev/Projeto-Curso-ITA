package br.iesb.poo;

public class Paciente {
    private final Double altura;
    private final Double peso;

    public Paciente(Double altura, Double peso) {
        this.altura = altura;
        this.peso = peso;
    }

    public Double getAltura() {
        return altura;
    }

    public Double getPeso() {
        return peso;
    }

    public Double calcularIMC()
    {
        return (peso / (altura * altura));
    }

    public String diagnostico()
    {
        double imc = this.calcularIMC();
        String result = "";
        if (imc < 16)
            result = " Baixo Peso Muito Grave.";
        if ((imc >= 16) && (imc < 16.99))
            result = " Baixo Peso Grave.";
        if ((imc >= 17) && (imc < 18.49))
            result = " Baixo Peso.";
        if ((imc >= 18.50) && (imc < 24.99))
            result = " Peso Normal.";
        if ((imc >= 25) && (imc < 29.99))
            result = " Sobrepeso.";
        if ((imc >= 30) && (imc < 34.99))
            result = " Obesidade Grau I.";
        if ((imc >= 35) && (imc < 39.99))
            result = " Obesidade Grau II.";
        if ((imc >= 40))
            result = " Obesidade Grau III. (Obesidade Mórbida)";

        return result;
    }
}
