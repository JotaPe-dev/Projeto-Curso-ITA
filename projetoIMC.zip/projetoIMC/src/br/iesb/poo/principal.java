package br.iesb.poo;

import br.iesb.poo.Paciente;
import java.io.FileNotFoundException;
import java.io.IOException;

public class principal {

    public static void main(String[] args) throws FileNotFoundException, IOException {

        Paciente pac1 = new Paciente(1.60, 80.0);
        Paciente pac2 = new Paciente(1.60, 70.0);
        Paciente pac3 = new Paciente(1.80, 82.1);


        System.out.println("Paciente 1: IMC: " + pac1.calcularIMC() + " Diagnóstico: " + pac1.diagnostico());
        System.out.println("Paciente 2: IMC: " + pac1.calcularIMC() + " Diagnóstico: " + pac2.diagnostico());
        System.out.println("Paciente 3: IMC: " + pac1.calcularIMC() + " Diagnóstico: " + pac3.diagnostico());

    }
}